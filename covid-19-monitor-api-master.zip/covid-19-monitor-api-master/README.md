COVID-19 Monitor API
====================

Serve project locally
---------------------
```bash
php -S localhost:8080 -t public
```
